summary.SpatialStreamNetwork <- function(object,...)
{
    show(object)
}

print.SpatialStreamNetwork <- function(x, ...)
{
    show(x)
}
