exp.Euclid <-
function(parsil, distance.matrix)
{
parsil*exp(-3*distance.matrix)
}

