### R code from vignette source 'SSN.Rnw'

