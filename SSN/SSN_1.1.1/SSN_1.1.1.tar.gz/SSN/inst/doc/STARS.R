### R code from vignette source 'STARS.Rnw'

