cau.Euclid <-
function(parsil, distance.matrix)
{
parsil/(1 + 4.4*distance.matrix^2)
}

